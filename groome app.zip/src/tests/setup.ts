
// This file is referenced in vite.config.ts
// It can be used to set up testing libraries, e.g., @testing-library/react/cleanup-after-each
// For now, it's empty as we don't have complex setup needs.
